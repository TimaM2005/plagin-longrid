<?php
$string['pluginname'] = 'longread';
$string['name'] = 'Name';
$string['content'] = 'Content';
